#include<iostream>
using namespace std;

int main()
{
    int i=100;
    int j=1;
    while(i>=1 && j<=100){
      cout<<"i = "<<i<<" dan "<<"j = "<<j<<endl;
      i--;
      j++;
    }
    return 0;
}
